#!/usr/bin/env bash
set -euo pipefail

ROOT="${ANNA_LORA_ROOT:-/workspace/anna_lora}"
SD_SCRIPTS_DIR="${SD_SCRIPTS_DIR:-$ROOT/sd-scripts}"
RUN_DIR="$ROOT/training_runs/anna_v2_strict011_sdxl_public_v0_1_2026-07-15"
CONFIG="$RUN_DIR/training_config.toml"
DATASET_CONFIG="$RUN_DIR/dataset_config.toml"

mkdir -p "$RUN_DIR/logs" "$RUN_DIR/outputs"
cd "$SD_SCRIPTS_DIR"

accelerate launch sdxl_train_network.py \
  --config_file "$CONFIG" \
  --dataset_config "$DATASET_CONFIG" \
  2>&1 | tee "$RUN_DIR/logs/train_$(date -u +%Y%m%dT%H%M%SZ).log"
