#!/usr/bin/env bash
set -euo pipefail

ROOT="${ANNA_LORA_ROOT:-/workspace/anna_lora}"
ARCHIVE="${1:-/workspace/anna_v2_strict011_sdxl_public_v0_1_2026-07-15_FULL_WITH_DATASET.tar.gz}"
RUN_NAME="anna_v2_strict011_sdxl_public_v0_1_2026-07-15"
RUN_DIR="$ROOT/training_runs/anna_v2_strict011_sdxl_public_v0_1_2026-07-15"
MODEL_PATH="$ROOT/models/lustifySDXLNSFW_ggwpV7.safetensors"
MODEL_URL="https://huggingface.co/aboba2005/lustifySDXLNSFW_ggwpV7/resolve/main/lustifySDXLNSFW_ggwpV7.safetensors"

mkdir -p "$ROOT" "$ROOT/models" "$ROOT/training_runs" "$ROOT/datasets"

echo "[strict011-sdxl-public] unpacking $ARCHIVE"
tar -xzf "$ARCHIVE" -C "$ROOT"

rm -rf "$ROOT/datasets/anna_x_model"
mv "$ROOT/$RUN_NAME/dataset/anna_x_model" "$ROOT/datasets/anna_x_model"
rm -rf "$RUN_DIR"
mv "$ROOT/$RUN_NAME/training_packet" "$RUN_DIR"

echo "[strict011-sdxl-public] installing sd-scripts"
if [ ! -d "$ROOT/sd-scripts/.git" ]; then
  git clone --depth 1 https://github.com/kohya-ss/sd-scripts.git "$ROOT/sd-scripts"
fi
cd "$ROOT/sd-scripts"
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
python3 -m pip install bitsandbytes prodigyopt lycoris-lora tensorboard

mkdir -p /root/.cache/huggingface/accelerate
cat > /root/.cache/huggingface/accelerate/default_config.yaml <<'YAML'
compute_environment: LOCAL_MACHINE
debug: false
distributed_type: 'NO'
downcast_bf16: 'no'
gpu_ids: all
machine_rank: 0
main_training_function: main
mixed_precision: bf16
num_machines: 1
num_processes: 1
rdzv_backend: static
same_network: true
tpu_env: []
tpu_use_cluster: false
tpu_use_sudo: false
use_cpu: false
YAML

if [ ! -f "$MODEL_PATH" ]; then
  echo "[strict011-sdxl-public] downloading public SDXL checkpoint"
  export MODEL_URL MODEL_PATH
  python3 - <<'PY'
import os
import urllib.request
url = os.environ["MODEL_URL"]
path = os.environ["MODEL_PATH"]
tmp = path + ".part"
with urllib.request.urlopen(url, timeout=180) as response, open(tmp, "wb") as out:
    while True:
        chunk = response.read(1024 * 1024)
        if not chunk:
            break
        out.write(chunk)
os.replace(tmp, path)
PY
fi

echo "[strict011-sdxl-public] starting training"
ANNA_LORA_ROOT="$ROOT" SD_SCRIPTS_DIR="$ROOT/sd-scripts" bash "$RUN_DIR/train_strict011_sdxl_public.sh"
