# anna_v2_strict011_sdxl_public_v0_1_2026-07-15

No-secret diagnostic SDXL LoRA payload for Anna v2 strict011.

- Trigger: `annav2strict011`
- Images: 5
- Base checkpoint: public `lustifySDXLNSFW_ggwpV7.safetensors`
- No HF token required
- No archive key required
