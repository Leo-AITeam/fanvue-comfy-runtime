# Anna v2 AI Model Lab Sanitized Dataset Pack

This package is the next practical move after the AI Model Lab materials review.

## Files

- `anna_v2_dataset_creator_v3_sanitized_smoke.workflow.json`
  - Sanitized ComfyUI workflow based on AI Model Lab `ai_model_lab_dataset_creator_v3.json`.
  - NSFW / bikini / large-breast / seductive prompts removed.
  - Anna v2 SFW identity prompts inserted.

- `upstream/ai_model_lab_dataset_creator_v3.original.json`
  - Original workflow copy for comparison.

- `inputs/anna_v2_master_011_between_warm.jpg`
  - Selected master face input.

- `prompts/anna_v2_sfw_identity_smoke_prompts.md`
  - Human-readable smoke prompt pack and QC criteria.

## Run order

1. Start one RunPod pod only.
2. Use A40 if available, otherwise RTX 4090.
3. Do not use L40S.
4. Upload `inputs/anna_v2_master_011_between_warm.jpg` to ComfyUI input root as `anna_v2_master_011_between_warm.jpg`.
5. Load `anna_v2_dataset_creator_v3_sanitized_smoke.workflow.json` into ComfyUI.
6. Verify missing nodes/models before queueing.
7. Run only the 12-image smoke batch.
8. Download outputs and create a contact sheet.
9. Do not scale until the smoke batch passes QC.

## Required model stack from AI Model Lab materials

Flux Klein branch:

- `flux-2-klein-9b-fp8.safetensors`
- `qwen_3_8b_fp8mixed.safetensors`
- `flux2-vae.safetensors`

Z-Image branch:

- `z-image-turbo-fp8-e4m3fn.safetensors`
- `qwen_3_4b.safetensors`
- `ultrafluxVAEImproved_v10.safetensors`

Captioning later:

- `Florence-2-SD3-Captioner`
- WD14 tagger model used by the caption workflow

## Required custom-node families

- ComfyUI-Manager
- WAS Node Suite
- pysssss Custom Scripts
- rgthree
- KJNodes
- CR Prompt List nodes
- ReferenceLatent-related nodes
- Florence2 caption nodes
- WD14 tagger nodes

## Stop condition

If ComfyUI reports missing core nodes or missing Flux/Z-Image models, stop generation and fix environment first. Do not substitute random SDXL workflows for this smoke test.

