# Anna v2 SFW Identity Smoke Prompts

Goal: create a controlled SFW identity dataset seed pack, not final Fanvue content.

Global identity:

`Anna Novari, adult Ukrainian woman in her mid twenties, warm tan skin close to the selected 001/011 reference, no freckles, natural darker blonde hair with darker roots, grey-blue eyes, slightly rounded chin, realistic skin texture with visible pores, sharp face details, natural phone-camera realism`

Global negative:

`freckles, pale skin, red hair, orange hair, black hair, plastic skin, wax skin, beauty filter, airbrushed skin, doll face, teen-coded, childlike, underage, anime, illustration, CGI, over-smoothed face, distorted chin, long sharp chin, wrong jaw, face drift, different person, blurry, soft focus, low resolution, bad anatomy, deformed eyes, asymmetrical eyes, extra teeth, watermark, text, logo, nude, explicit, lingerie, bikini, large breasts, silicone body`

## 12-image smoke set

1. Front close-up, neutral expression, direct eye contact, white wall, soft daylight.
2. Front close-up, subtle natural smile, direct gaze, white wall, soft window light.
3. Three-quarter left, head turned about 35 degrees, eyes to camera.
4. Three-quarter right, head turned about 35 degrees, eyes slightly past camera.
5. Left side profile, shoulders-up, clear profile and jawline.
6. Right side profile, shoulders-up, clear profile and jawline.
7. High-angle selfie, eyes looking up to camera.
8. Low-angle chest-up portrait, softly rounded chin.
9. Upper chest portrait, white ribbed tank top, direct gaze.
10. Waist-up portrait, warm grey fitted top, slight head tilt.
11. Indoor daylight portrait near bright window, simple apartment wall.
12. Warm indoor portrait, soft warm room light, SFW calm expression.

## Pass criteria

- At least 5/12 images are sharp.
- At least 4/12 keep Anna's identity.
- At least 3/12 show real angle variation.
- Skin is warm/tan, not pale.
- No freckles.
- Hair is natural darker blonde with darker roots.
- Chin is slightly rounded, not long/sharp.

